
	
	<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">USUARIOS</h3>
  </div>
  <div class="panel-body">
    
  	<div class="row">

		  <div class="col-md-12">
		  	
		  	<!-- Se carga la tabla de los pedidos -->
		  	<div id="listaUsuarios"></div>


		  </div>
		</form>
		</div>






  </div>
</div>

